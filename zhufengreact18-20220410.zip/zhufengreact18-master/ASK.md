hooks怎么错误捕获hooks怎么错误捕获



老师，redux是不是工作中会少使用？
他的意思是你的errorbounty是class组件用的
升18，react-router这些库要跟着升吗？
不需要
react-router-v6
fiber中reconciler已经有了优先级渲染，react18中的setState根据优先级渲染和之前的调度有什么不同
我选择用redux toolkit
我喜欢用mobx
大点的项目一般都会有状态管理





8对开发体验影响不大其实
react能用pinia吗
下周会讲pinia
yyds
老师，低优先级那块。
redux一般在怎样的项目上会使用啊
老师，低优先级那块。

我的理解是这样的，不知道对不：
react17，所有的setXXX，都是相同的优先级吧？
然后react18setXXXX可以自动高优还是低优。
阿里的项目 貌似从不用redux，至少我没见过
阿里项目 用是umi dva 内部都会使用redux

用啥 redux  直接 context  够了
用不用redux全看你自己， 不一定非得用
那用什么 自己封装的吗
redux  写的烦死
我们用umi最多
应该是用dva吧，毕竟自己创造的轮子
搞清楚redux解决的问题就明白了
我也用umi啊 dva不就是在redux上封装了一层吗
redux toolkit。zustand都可呐，用一个自己趁手的兵器就行了
18能实现keepalive吗
https://www.reactrouter.cn/
keepalive还是
React18 在开发但是没有发布
SuspenseList
react keepalive OffScreen




iber中reconciler已经有了优先级渲染，
react18中的setState根据优先级渲染和之前的调度有什么不同
之前react团队不是说过不会实现keepalive么
看来我的主管估计也不太懂。。我的主管说 redux太重了，所以用umi 比较轻量～～
fiber中reconciler已经有了优先级渲染，react18中的setState根据优先级渲染和之前的调度有什么不同
这是 讲解 vite 源码吗
fiber中reconciler已经有了优先级渲染，react18中的setState根据优先级渲染和之前的调度有什么不同
推一下课程大纲吧 张老师
无视吗
fiber中reconciler已经有了优先级渲染，react18中的setState根据优先级渲染和之前的调度有什么不同
umi只是提高开发体验和效率